package hungry.redball.alram.model;

/**
 * Created by soy on 2015-12-09.
 */
public class Grid {
    int flag;
    String teamName;

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }


}
