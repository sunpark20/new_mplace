package hungry.redball.aStatic;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.os.PowerManager;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

/**
 * Created by soy on 2015-11-26.
 */
public class StaticMethod {
    private static PowerManager.WakeLock sCpuWakeLock;
    public static JSONArray[] jArr=new JSONArray[5];
    public static JSONArray[] jArr_team=new JSONArray[5];
    public static boolean TT_RepeatReceiver;

    //shared preference
    public static String fristStrat_p;

    public static void fToast(Context context, String string){
        Toast.makeText(context, string, Toast.LENGTH_SHORT).show();
    }
    //네트워크 연결상태 체크 메소드
    public static boolean isNetworkConnected(Context context){
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting())
            return true;
        return false;
    }

    //파일 저장
    public static void saveJsonFile(Context context, JSONObject jsonObject) throws Exception{
        String state = Environment.getExternalStorageState();
        String externalPath = null;
        if (state.equals(Environment.MEDIA_MOUNTED)) {
            externalPath = Environment.getExternalStorageDirectory()
                    .getAbsolutePath();
        } else if (state.equals(Environment.MEDIA_UNMOUNTED)) {
            Toast.makeText(context, "MEDIA_UNMOUNTED", Toast.LENGTH_SHORT).show();
        } else if (state.equals(Environment.MEDIA_UNMOUNTABLE)) {
            Toast.makeText(context, "MEDIA_UNMOUNTABLE", Toast.LENGTH_SHORT).show();
        }
        String dirName = context.getPackageName();
        File file = new File(externalPath + "/" + dirName);
        file.mkdir();
        String path = externalPath + "/" + dirName;
        PrintWriter writer = new PrintWriter(path + "/league_team_korean.json");
        String str=jsonObject.toString();
        writer.print((Object)str);
        writer.close();
        Log.e("파일 만들기", "파일만들기 완료");
    }

    //파일 읽기
    public static String loadJSONFromAsset(String fileName, Context c) {
        String json = null;
        try {
            InputStream is = c.getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    public static void acquireCpuWakeLock(Context context) {
        Log.e("PushWakeLock", "Acquiring cpu wake lock");
        Log.e("PushWakeLock", "wake sCpuWakeLock = " + sCpuWakeLock);

        if (sCpuWakeLock != null) {
            return;
        }
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        sCpuWakeLock = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK |
                        PowerManager.ACQUIRE_CAUSES_WAKEUP |
                        PowerManager.ON_AFTER_RELEASE, "hello");

        sCpuWakeLock.acquire();
    }

    public static void releaseCpuLock() {
        Log.e("PushWakeLock", "Releasing cpu wake lock");
        Log.e("PushWakeLock", "relase sCpuWakeLock = " + sCpuWakeLock);

        if (sCpuWakeLock != null) {
            sCpuWakeLock.release();
            sCpuWakeLock = null;
        }
    }

    public static int sToi(String str){
        int newInt=Integer.parseInt(str);
        return newInt;
    }
    public static String iTos(int i){
        String s=String.valueOf(i);
        return s;
    }


}
