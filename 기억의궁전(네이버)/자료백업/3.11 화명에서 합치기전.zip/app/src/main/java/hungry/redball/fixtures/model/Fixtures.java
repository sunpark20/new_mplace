package hungry.redball.fixtures.model;

/**
 * Created by soy on 2015-07-01.
 */
public class Fixtures {
    int hFlag,aflag;
    String date, home, away, hscore, ascore;

    public int gethFlag() {
        return hFlag;
    }

    public void sethFlag(int hFlag) {
        this.hFlag = hFlag;
    }

    public int getAflag() {
        return aflag;
    }

    public void setAflag(int aflag) {
        this.aflag = aflag;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getHome() {
        return home;
    }

    public void setHome(String home) {
        this.home = home;
    }

    public String getAway() {
        return away;
    }

    public void setAway(String away) {
        this.away = away;
    }

    public String getHscore() {
        return hscore;
    }

    public void setHscore(String hscore) {
        this.hscore = hscore;
    }

    public String getAscore() {
        return ascore;
    }

    public void setAscore(String ascore) {
        this.ascore = ascore;
    }
}
